import os

def main():
    os.system("python scripts/train.py")
    os.system("python scripts/evaluate.py")

if __name__ == "__main__":
    main()
